/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largeclock;

import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;
/**
 *
 * @author kristhian
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Text ShowTimeText;
     
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Timer t = new Timer();
t.schedule(new TimerTask() {
    @Override
    public void run() {
        Date date = new Date();
        ShowTimeText.setText(Long.toString(date.getHours())+":"+Long.toString(date.getMinutes())+":"+Long.toString(date.getSeconds()));
    }
}, 0, 1000);
    }    
    
}
